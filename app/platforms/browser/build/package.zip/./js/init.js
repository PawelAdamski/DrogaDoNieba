


document.addEventListener('deviceready', app.init.bind(app), false);
window.onload = app.init.bind(app);


